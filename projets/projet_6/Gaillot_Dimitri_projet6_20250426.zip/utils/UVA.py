import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
#%matplotlib inline

import warnings
warnings.filterwarnings('ignore')
pd.options.mode.chained_assignment = None  # default='warn'


def category(data, var_group_list, width=7, height=5):
  '''
  Univariate_Analysis_categorical
  takes a group of variables (category) and plot/print all the value_counts and barplot.
  '''
  # setting figure_size
  size = len(var_group_list)
  plt.figure(figsize = (width*size, height), dpi = 100)

  # for every variable
  for j,i in enumerate(var_group_list):
    norm_count = data[i].value_counts(normalize = True)
    n_uni = data[i].nunique()

  #Plotting the variable with every information
    plt.subplot(1,size,j+1)
    ax = sns.barplot(x=round(norm_count*100, 2), y=norm_count.index , order = norm_count.index)
    plt.xlabel('fraction/percent', fontsize = 20)
    plt.ylabel('{}'.format(i), fontsize = 20)
    #plt.title('n_uniques = {} \n value counts \n {};'.format(n_uni,norm_count))
    plt.title('n_uniques = {}'.format(n_uni))
    var = ax.bar_label(ax.containers[0], rotation=0, padding=2)
    plt.show()


def numeric(data, i):
    '''
    Univariate_Analysis_numeric
    Takes a group of variables (INTEGER and FLOAT) and plot/print 
        all the descriptives and properties along with KDE.
    Runs a loop: calculate all the descriptives of i(th) variable 
        and plot/print it.
    '''
    # calculating descriptives of variable
    mini = data[i].min()
    maxi = data[i].max()
    ran = data[i].max()-data[i].min()
    mean = data[i].mean()
    median = data[i].median()
    st_dev = data[i].std()
    skew = data[i].skew()
    kurt = data[i].kurtosis()

    # calculating points of standard deviation
    points = mean-st_dev, mean+st_dev

    #Plotting the variable with every information
    sns.kdeplot(data[i]
                  #, shade=True
                  , fill=True
                )
    max_ax = (sns.kdeplot(data[i].to_numpy()).lines[0].get_xydata())[:, 1].max()
    y_line = [max_ax/100, max_ax/100]
    y_point = [max_ax/100]
    sns.lineplot(x = points, y=y_line, color = 'black', label = "marg_err")
    sns.scatterplot(x=[mini,maxi], y=y_line, color = 'orange', label = "min/max")
    sns.scatterplot(x=[mean], y=y_point, color = 'red', label = "mean")
    sns.scatterplot(x=[median], y=y_point, color = 'blue', label = "median")
    plt.xlabel('{}'.format(i), fontsize = 20)
    plt.ylabel('density')
    plt.title('margin_error = {}; kurtosis = {};\nskew = {}; range = {}\nmean = {}; median = {}'.format((round(points[0],2),round(points[1],2)),
                                                                                                   round(kurt,2),
                                                                                                   round(skew,2),
                                                                                                   (round(mini,2),round(maxi,2),round(ran,2)),
                                                                                                   round(mean,2),
                                                                                                   round(median,2)))



def num_plus(df, indicators_list):
    for i in indicators_list:
        plt.figure(figsize = (15, 20))
        df_indic = df[i]

        plt.subplot(5,2,1)
        sns.boxplot(y=df_indic
                    , showmeans=True
                    , meanprops={"marker":"s","markerfacecolor":"white", "markeredgecolor":"green"}
                   )
        plt.xlabel(f'{i}', fontsize = 20)

        plt.subplot(5,2,2)
        numeric(df, i)


def ping():
    """
    You call ping I print pong.
    """
    print('pong')
